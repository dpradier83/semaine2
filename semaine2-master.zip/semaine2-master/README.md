# semaine2


## badges codecademy


Voici le lien qui permet de voir les badges que j'ai pu obtenir sur codecademy : 
https://www.codecademy.com/users/Damienpradier/achievements

## exercices déjà réalisés

J'ai appris à créer un repository sur github et à le synchroniser avec 
mon compte sur cloud9. une fois le repository terminé, j'ai appris à le pusher
vers github.

J'ai déjà fait les modules HTML & CSS et Make a website sur codecademy.